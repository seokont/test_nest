export class Auto {}
